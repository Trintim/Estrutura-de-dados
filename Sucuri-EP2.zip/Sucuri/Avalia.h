/*
 * ESTE ARQUIVO NÃO DEVE SER MODIFICADO
 */
#ifndef EP2_AVALIA_H
#define EP2_AVALIA_H

#include "Objeto.h"
#include "Fila.h"

Objeto *avalia(Fila *);

#endif //EP2_AVALIA_H
